package com.yukthitech.autox.ide.help;

import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.commons.collections.CollectionUtils;

import com.yukthitech.autox.doc.DocInformation;
import com.yukthitech.autox.doc.PluginInfo;
import com.yukthitech.autox.doc.StepInfo;

public class PluginInfoTreeNode extends DefaultMutableTreeNode//FilterableTreeNode
{
	private static final long serialVersionUID = 1L;
	private String name;
	private PluginInfo pluginInfo;

	public PluginInfoTreeNode(PluginInfo pluginInfo, DocInformation docInformation)
	{
		super(pluginInfo.getName());
		this.name=pluginInfo.getName();
		this.pluginInfo = pluginInfo;
		
		for(StepInfo step : docInformation.getSteps())
		{
			if(step.getRequiredPlugins().contains(pluginInfo.getName()))
			{
				super.add(new StepInfoTreeNode(step, docInformation));
			}
		}
	}

	public PluginInfoTreeNode(String name, DocInformation docInformation)
	{
		super(name);
		this.name=name;
		for(StepInfo step : docInformation.getSteps())
		{
			if(CollectionUtils.isEmpty(step.getRequiredPlugins()))
			{
				super.add(new StepInfoTreeNode(step, docInformation));
			}
		}
	}
	public void addStep(StepInfoTreeNode step){
		super.add(step);
	}

	public PluginInfo getPluginInfo()
	{
		
		return pluginInfo;
	}

	public String getName()
	{
		// TODO Auto-generated method stub
		return name;
	}

}
