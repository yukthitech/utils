package com.yukthitech.autox.ide.ui;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.swing.Icon;

import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;

import com.yukthitech.utils.exceptions.InvalidStateException;

public class BaseTreeTableNode  extends DefaultMutableTreeTableNode{
	String id;
	Icon icon;
	String label;
	
	private Map<String, BaseTreeTableNode> childNodes  = new LinkedHashMap<>();
	
	public BaseTreeTableNode() {
		// TODO Auto-generated constructor stub
	}
	public BaseTreeTableNode(Icon icon, String label) {
		
		this.icon=icon;
		this.label=label;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Icon getIcon() {
		return icon;
	}
	public void setIcon(Icon icon) {
		this.icon = icon;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	
	public void addChild(String id,BaseTreeTableNode node){
		if(childNodes.containsKey(id))
		{
			throw new InvalidStateException("A node with specified id already exist: {}", id);
		}
		node.id= id;
		childNodes.put(id, node);
		super.add(node);
	}
	
	public Collection<BaseTreeTableNode> getChildNodes()
	{
		return childNodes.values();
	}
	public void reload(){
		
	}
}
