package com.yukthitech.autox.ide.postman;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.annotation.PostConstruct;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.border.EmptyBorder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Postman extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JSplitPane splitPane;
	private PostmanRequest postmanRequest;
	@Autowired
	private PostmanResponse postmanResponse;
	/**
	 * Create the panel.
	 */
	public Postman() {
		
	}
	@PostConstruct
	public void init(){
		setBorder(new EmptyBorder(5, 5, 5, 5));
		setLayout(new BorderLayout(0, 0));
		add(getSplitPane());
	}
	private JSplitPane getSplitPane() {
		if (splitPane == null) {
			splitPane = new JSplitPane();
			splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
			postmanRequest = new PostmanRequest();
			splitPane.setLeftComponent(postmanRequest);
			splitPane.setRightComponent(getPostmanResponse());
			splitPane.setMinimumSize(new Dimension(10, 10));
		}
		return splitPane;
	}
	private PostmanResponse getPostmanResponse() {
//		if (postmanResponse == null) {
//			postmanResponse = new PostmanResponse();
//		}
		postmanResponse.init();
		return postmanResponse;
	}
}
