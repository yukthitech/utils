package com.yukthitech.autox.ide.views.report;

import java.awt.Component;

import javax.swing.JEditorPane;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

public class MessageRenderer extends JEditorPane implements TableCellRenderer
{
	JEditorPane jEditorPane;

	@Override
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
	{
		if(value!=null)
		{
			setContentType("text/html");
			setText((String) value);
			
		}
		else{
			setText(null);
		}
		 table.setRowHeight(30);
		return this;
	}

}
