package com.yukthitech.autox.ide.ui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JEditorPane;
import javax.swing.tree.DefaultMutableTreeNode;

import org.jdesktop.swingx.treetable.AbstractTreeTableModel;
import org.jdesktop.swingx.treetable.TreeTableModel;

import com.yukthitech.autox.ide.views.report.LogReportEntry;
import com.yukthitech.autox.ide.views.report.TestSuiteReport;

public class ReportTreeTableModel extends AbstractTreeTableModel
{
	
	private final static String[] columnNames = { "Log Level", "Source", "Message", "Time" };
	
	private List<TestSuiteReport> testSuite;

	public ReportTreeTableModel(List<TestSuiteReport> testSuite)
	{
		super(new Object());
		this.testSuite = testSuite;
	}

	@Override
	public int getColumnCount()
	{
		return columnNames.length;
	}

	@Override
	public String getColumnName(int column)
	{
		
		return columnNames[column];
	}
	
	@Override
	public boolean isLeaf(Object node)
	{
		return node instanceof LogReportEntry;
	}

	@Override
	public int getChildCount(Object parent)
	{
		if(parent instanceof TestSuiteReport)
		{
			TestSuiteReport tsr = (TestSuiteReport) parent;
			return tsr.getTestCaseReports().size();
		}
		if(parent instanceof TestCaseReport)
		{
			TestCaseReport tcr = (TestCaseReport) parent;
			return tcr.getLogs().size();
		}
		return testSuite.size();
	}

	@Override
	public Object getChild(Object parent, int index)
	{

		if(parent instanceof TestSuiteReport)
		{
			TestSuiteReport tsr = (TestSuiteReport) parent;
			return tsr.getTestCaseReports().get(index);
		}
		if(parent instanceof TestCaseReport)
		{
			TestCaseReport tcr = (TestCaseReport) parent;
			return tcr.getLogs().get(index);
		}
		return testSuite.get(index);
	}

	@Override
	public int getIndexOfChild(Object parent, Object child)
	{
		TestCaseReport tcr = (TestCaseReport) parent;
		LogReportEntry log = (LogReportEntry) child;
		return tcr.getLogs().indexOf(child);
	}

	@Override
	public Object getValueAt(Object node, int column)
	{
		if(node instanceof TestSuiteReport)
		{
			TestSuiteReport tsr = (TestSuiteReport) node;
			switch(column){
				case 0:
					return tsr.getName();
				default:
					return "";
						
			}
			
		}
		if(node instanceof TestCaseReport)
		{
			TestCaseReport tcr = (TestCaseReport) node;
			switch(column){
				case 0:
					return tcr.getName();
				default:
					return "";
						
			}
			
		}
		else if(node instanceof LogReportEntry)
		{
			LogReportEntry log = (LogReportEntry) node;
			switch (column)
			{
				case 0:
					return log.getLogLevel();
				case 1:
					return log.getSource();
				case 2:
					return log.getMessage();
				case 3:
					return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(log.getTime());
					
			}
			
		}
		return null;
	}
}
