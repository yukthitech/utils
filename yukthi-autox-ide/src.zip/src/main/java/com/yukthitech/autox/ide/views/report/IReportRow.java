package com.yukthitech.autox.ide.views.report;

public interface IReportRow
{
	public Object getValueAt(int col);
}
