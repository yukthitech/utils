package com.yukthitech.autox.ide;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Window;

import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;

public class ReportMessageDialog extends JDialog
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JScrollPane scrollPane;
	private JEditorPane editorPane;

	private String message;
	/**
	 * Launch the application.
	 */

	/**
	 * Create the dialog.
	 */
	public ReportMessageDialog(Window window,String str)
	{
		super(window, ModalityType.APPLICATION_MODAL);
		this.message=str;
		getContentPane().add(getScrollPane(), BorderLayout.CENTER);
		setSize(new Dimension(700, 300));
		
	}
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane(getEditorPane());
		}
		return scrollPane;
	}
	private JEditorPane getEditorPane() {
		if (editorPane == null) {
			editorPane = new JEditorPane("text/html",message);
		}
		return editorPane;
	}
	public void display(){
		super.setVisible(true);
	}
}
