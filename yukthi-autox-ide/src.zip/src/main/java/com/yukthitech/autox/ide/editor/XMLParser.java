package com.yukthitech.autox.ide.editor;

import org.fife.ui.rsyntaxtextarea.RSyntaxDocument;
import org.fife.ui.rsyntaxtextarea.parser.AbstractParser;
import org.fife.ui.rsyntaxtextarea.parser.ParseResult;

public class XMLParser extends AbstractParser
{
	public static final String PROPERTY_AST="XmlAST";
	
	public XMLParser()
	{
		// TODO Auto-generated constructor stub
	}
	@Override
	public ParseResult parse(RSyntaxDocument doc, String style)
	{
		// TODO Auto-generated method stub
		return null;
	}
	
}
