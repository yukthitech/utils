package com.yukthitech.autox.ide.exeenv;

public class EnvConsole
{

}
