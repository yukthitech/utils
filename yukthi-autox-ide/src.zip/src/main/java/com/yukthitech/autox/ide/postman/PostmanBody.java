package com.yukthitech.autox.ide.postman;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;

public class PostmanBody extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTable table1;

	private JPanel form_data;
	private RSyntaxTextArea rSyntaxTextArea;
	private DefaultTableModel defaultTableModel;

	/**
	 * Create the panel.
	 */
	public PostmanBody() {
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 107, 265, 0 };
		gridBagLayout.rowHeights = new int[] { 0, 0, 0, 0 };
		gridBagLayout.columnWeights = new double[] { 0.0, 1.0, Double.MIN_VALUE };
		gridBagLayout.rowWeights = new double[] { 0.0, 0.0, 1.0, Double.MIN_VALUE };
		setLayout(gridBagLayout);

		ButtonGroup buttonGroup = new ButtonGroup();

		JRadioButton rdbtnNewRadioButton = new JRadioButton("form-data");
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rSyntaxTextArea.setVisible(false);
				form_data.setVisible(true);
			}
		});
		rdbtnNewRadioButton.setSelected(true);
		GridBagConstraints gbc_rdbtnNewRadioButton = new GridBagConstraints();
		gbc_rdbtnNewRadioButton.anchor = GridBagConstraints.WEST;
		gbc_rdbtnNewRadioButton.insets = new Insets(0, 0, 5, 5);
		gbc_rdbtnNewRadioButton.gridx = 0;
		gbc_rdbtnNewRadioButton.gridy = 1;
		add(rdbtnNewRadioButton, gbc_rdbtnNewRadioButton);

		JRadioButton radioButton = new JRadioButton("raw");
		radioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				form_data.setVisible(false);
				rSyntaxTextArea.setVisible(true);
			}
		});
		GridBagConstraints gbc_radioButton = new GridBagConstraints();
		gbc_radioButton.anchor = GridBagConstraints.WEST;
		gbc_radioButton.insets = new Insets(0, 0, 5, 0);
		gbc_radioButton.gridx = 1;
		gbc_radioButton.gridy = 1;
		add(radioButton, gbc_radioButton);

		buttonGroup.add(rdbtnNewRadioButton);
		buttonGroup.add(radioButton);

		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.gridwidth = 2;
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 2;
		add(panel, gbc_panel);
		panel.setLayout(new CardLayout(0, 0));

		form_data = new JPanel();
		panel.add(form_data, "name_15379027355504");
		String columnNames[] = { "Key", "Value" };
		defaultTableModel = new DefaultTableModel(columnNames, 1);
		table1 = new JTable(defaultTableModel);
		table1.getTableHeader();
		form_data.setLayout(new BorderLayout(0, 0));
		JScrollPane scrollPane = new JScrollPane(table1);
		form_data.add(scrollPane);

		table1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				if (table1.getSelectedRow() == table1.getRowCount() - 1) {
					defaultTableModel.addRow(new Object[] { "", "" });
					table1.validate();
				}

			}
		});

		rSyntaxTextArea = new RSyntaxTextArea();
		panel.add(rSyntaxTextArea, "name_15370265096477");
	}

}
