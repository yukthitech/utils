package com.yukthitech.autox.ide.views.report;

import java.util.Arrays;
import java.util.List;
import java.util.Vector;

import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;

import com.yukthitech.autox.ide.ui.TestCaseReport;

public class TestSuiteReport {
	private List<TestCaseReport> testCaseReports;
	
	private String name;	
	
	
	public TestSuiteReport(String name, List<TestCaseReport> testCaseReport )
	{
		this.name=name;
		this.testCaseReports=testCaseReport;
	}


	public List<TestCaseReport> getTestCaseReports()
	{
		return testCaseReports;
	}


	public void setTestCaseReports(List<TestCaseReport> testCaseReports)
	{
		this.testCaseReports = testCaseReports;
	}


	public String getName()
	{
		return name;
	}


	public void setName(String name)
	{
		this.name = name;
	}
}
