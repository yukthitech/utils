package com.yukthitech.autox.ide;

public interface IMaximizationListener
{
	public void flipMaximizationStatus(MaximizableTabbedPane tabPane);
	
	public void minimize(MaximizableTabbedPane tabPane);
}
