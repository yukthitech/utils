package com.yukthitech.autox.ide.postman;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class PostmanHeaders extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JScrollPane scrollPane;
	private JTable table;
	private DefaultTableModel defaultTableModel;

	/**
	 * Create the panel.
	 */
	public PostmanHeaders() {
		String columnNames[]={"Key","Value"};
		defaultTableModel = new DefaultTableModel(columnNames, 1);
		table = new JTable(defaultTableModel);
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				if(table.getSelectedRow()==table.getRowCount()-1)
				{
					defaultTableModel.addRow(new Object[]{"",""});
					table.validate();
				}
				
			}
		});
		setLayout(new BorderLayout(0, 0));
		table.setCellSelectionEnabled(true);
		add(table);
		
		scrollPane = new JScrollPane(table);
		add(scrollPane);
		

	}

}
