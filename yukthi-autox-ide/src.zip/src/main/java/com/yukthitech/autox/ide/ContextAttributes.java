package com.yukthitech.autox.ide;

import javax.annotation.PostConstruct;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTabbedPane;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.yukthitech.autox.ide.layout.ActionCollection;
import com.yukthitech.autox.ide.layout.UiLayout;
import com.yukthitech.autox.ide.views.IViewPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
@Component
public class ContextAttributes extends JPanel implements IViewPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Create the panel.
	 */
	@Autowired
	private UiLayout uiLayout;

	@Autowired
	private ActionCollection actionCollection;
	
	private JTabbedPane parentTabbedPane;
	
	private JScrollPane scrollPane;
	
	private JTable table;
	
	private JPopupMenu ctxAttributePopup;
	
	public ContextAttributes() {
		setLayout(new BorderLayout(0, 0));
		
	}
	@PostConstruct
	public void init() {
		add(getScrollPane());
	}

	@Override
	public void setParent(JTabbedPane parentTabPane) {
		// TODO Auto-generated method stub
		this.parentTabbedPane=parentTabPane;
	}

	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane(getTable());
		}
		return scrollPane;
	}
	private JTable getTable() {
		if (table == null) {
			table = new JTable();
			table.setModel(new DefaultTableModel(
				new Object[][] {
					{null, null},
					{null, null},
					{null, null},
				},
				new String[] {
					"Key", "Value"
				}
			));
		}
		ctxAttributePopup  = uiLayout.getPopupMenu("postmanResponsePopup").toPopupMenu(actionCollection);
		table.setComponentPopupMenu(ctxAttributePopup);
		return table;
	}
}
