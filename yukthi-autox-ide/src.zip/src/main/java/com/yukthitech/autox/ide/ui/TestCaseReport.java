package com.yukthitech.autox.ide.ui;

import java.util.List;

import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;

import com.yukthitech.autox.ide.views.report.LogReportEntry;

public class TestCaseReport{
	String name;
	List<LogReportEntry> logs;
	public TestCaseReport(String name,List<LogReportEntry> logs) {
		this.name=name;
		this.logs=logs;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<LogReportEntry> getLogs() {
		return logs;
	}
	public void setLogs(List<LogReportEntry> logs) {
		this.logs = logs;
	}
	
	
}
