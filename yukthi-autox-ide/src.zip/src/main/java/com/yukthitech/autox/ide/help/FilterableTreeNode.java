package com.yukthitech.autox.ide.help;

import java.util.ArrayList;
import java.util.List;

import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.commons.lang3.StringUtils;

public class FilterableTreeNode extends DefaultMutableTreeNode
{
	private static final long serialVersionUID = 1L;

	private String label;
	
	private List<FilterableTreeNode> childNodes= new ArrayList<>();
	
	public FilterableTreeNode(String label)
	{
		super(label);
		this.label = label;
	}
	
	public void add(FilterableTreeNode newChild)
	{
		super.add(newChild);
		childNodes.add(newChild);
	}
	
	public boolean filter(String text)
	{
		super.removeAllChildren();
		
		boolean res = false;
		
		for(FilterableTreeNode child: childNodes)
		{
			if(child.filter(text))
			{
				super.add(child);
				res = true;
			}
		}
		
		if(StringUtils.isEmpty(text))
		{
			return true;
		}
		
		if(res)
		{
			return true;
		}
		
		return label.toLowerCase().contains(text);
	}
}
