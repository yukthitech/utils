package com.yukthitech.autox.ide.views.report;

import java.util.Date;
import java.util.Vector;

import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;

public class LogReportEntry {
	String logLevel;
	String source;
	String message;
	Date time;
	public LogReportEntry(String logLevel,String source,String message,Date time) {
		// TODO Auto-generated constructor stub
		this.logLevel=logLevel;
		this.source=source;
		this.message=message;
		this.time=time;
	}
	
	public String getLogLevel() {
		return logLevel;
	}
	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
		
}
