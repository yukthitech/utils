package com.yukthitech.autox.ide.actions;

import com.yukthitech.autox.ide.layout.Action;
import com.yukthitech.autox.ide.layout.ActionHolder;

@ActionHolder
public class PostmanResponseActions {
	@Action
	public void assertValue() {
		
	}
	@Action
	public void extract() {
		
	}
}
