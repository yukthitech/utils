package com.yukthitech.autox.ide.editor;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.fife.ui.autocomplete.AutoCompletion;
import org.fife.ui.autocomplete.BasicCompletion;
import org.fife.ui.autocomplete.CompletionProvider;
import org.fife.ui.autocomplete.DefaultCompletionProvider;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rtextarea.IconRowHeader;
import org.fife.ui.rtextarea.RTextScrollPane;
import org.fife.ui.rsyntaxtextarea.parser.Parser;
import org.fife.ui.rsyntaxtextarea.parser.XmlParser;
import org.fife.ui.rsyntaxtextarea.spell.SpellingParser;
import org.springframework.beans.factory.annotation.Autowired;

import com.yukthitech.autox.doc.DocGenerator;
import com.yukthitech.autox.doc.DocInformation;
import com.yukthitech.autox.doc.StepInfo;
import com.yukthitech.autox.ide.IdeUtils;
import com.yukthitech.autox.ide.context.IdeContext;
import com.yukthitech.autox.ide.model.Project;
import com.yukthitech.autox.ide.xmlfile.Attribute;
import com.yukthitech.autox.ide.xmlfile.Element;
import com.yukthitech.autox.ide.xmlfile.XmlFile;

public class FileEditor extends RTextScrollPane
{
	private static final long serialVersionUID = 1L;

	private static Logger logger = LogManager.getLogger(FileEditor.class);

	private Project project;

	private File file;

	private RSyntaxTextArea syntaxTextArea = new RSyntaxTextArea("");
	
	private IconRowHeader iconArea;

	@Autowired
	private IdeContext ideContext;
	
	private Parser parser; 
	
	private SpellingParser spellParser = null;

	public FileEditor(Project project, File file)
	{
		super(new RSyntaxTextArea());
		getGutter().setBookmarkIcon(IdeUtils.loadIcon("/ui/icons/bullet.png",7));
		getGutter().setBookmarkingEnabled(true);
		Field[] fields=getGutter().getClass().getDeclaredFields();
		for(Field f:fields){
			if(f.getType().equals(IconRowHeader.class)){
				f.setAccessible(true);
				try
				{
					iconArea = (IconRowHeader) f.get(getGutter());
				} catch(IllegalArgumentException | IllegalAccessException e1)
				{
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		iconArea.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
//				if(SwingUtilities.isLeftMouseButton(e)||e.getClickCount()==2){
//					try {
//						int line =viewToModelLine(e.getPoint());
//						iconArea.addOffsetTrackingIcon(line,IdeUtils.loadIcon("/ui/icons/bullet.png", 7),"tip");
//					}catch(Exception ex) {
//						ex.printStackTrace();
//					}
//					
//				}
				if(SwingUtilities.isRightMouseButton(e)){
					GutterPopup popup =new GutterPopup(); 
					iconArea.add(popup);
					popup.show(e.getComponent(),e.getX(),e.getY());					
				}
			}
//			private int viewToModelLine(Point p) throws BadLocationException {
//				int offs = syntaxTextArea.viewToModel(p);
//				return offs>-1 ? syntaxTextArea.getLineOfOffset(offs) : -1;
//			}
		});
		this.project = project;
		this.syntaxTextArea = (RSyntaxTextArea) super.getViewport().getView();
		super.setLineNumbersEnabled(true);

		this.file = file;

		setSyntaxStyle();
		syntaxTextArea.setCodeFoldingEnabled(true);

		try
		{
			syntaxTextArea.setText(FileUtils.readFileToString(file));
		} catch(Exception ex)
		{
			ex.printStackTrace();
		}

		syntaxTextArea.getDocument().addDocumentListener(new DocumentListener()
		{
			@Override
			public void removeUpdate(DocumentEvent e)
			{
				fileContentChanged();
			}

			@Override
			public void insertUpdate(DocumentEvent e)
			{
				fileContentChanged();
			}

			@Override
			public void changedUpdate(DocumentEvent e)
			{
				fileContentChanged();
			}
		});
		CompletionProvider provider = getStepsProvider();
		AutoCompletion ac = new AutoCompletion(provider);
		// show documentation dialog box
		ac.setShowDescWindow(true);
		ac.install(syntaxTextArea);
	}

	private void setSyntaxStyle()
	{
		int extIdx = file.getName().lastIndexOf(".");
		String extension = null;

		if(extIdx > 0 && extIdx < file.getName().length() - 1)
		{
			extension = file.getName().substring(extIdx + 1).toLowerCase();
		}

		if("properties".equals(extension))
		{
			syntaxTextArea.setSyntaxEditingStyle(RSyntaxTextArea.SYNTAX_STYLE_PROPERTIES_FILE);
		}
		else if("xml".equals(extension))
		{
			syntaxTextArea.setSyntaxEditingStyle(RSyntaxTextArea.SYNTAX_STYLE_XML);
		}
		else if("json".equals(extension))
		{
			syntaxTextArea.setSyntaxEditingStyle(RSyntaxTextArea.SYNTAX_STYLE_JSON);
		}
	}

	public void setFile(File file)
	{
		this.file = file;
		setSyntaxStyle();
	}

	public Project getProject()
	{
		return project;
	}

	public void saveFile()
	{
		try
		{
			if(!file.canWrite())
			{
				int res = JOptionPane.showConfirmDialog(IdeUtils.getCurrentWindow(), "Current file '" + file.getName() + "' is read-only file. Do you still want to overwite the file?", "Save File", JOptionPane.YES_NO_OPTION);

				if(res == JOptionPane.NO_OPTION)
				{
					return;
				}

				file.setWritable(true);
			}

			FileUtils.write(file, syntaxTextArea.getText());
			ideContext.getProxy().fileSaved(file);
		} catch(Exception ex)
		{
			logger.debug("An error occurred while saving file: " + file.getPath(), ex);
			JOptionPane.showMessageDialog(this, "An error occurred while saving file: " + file.getName() + "\nError: " + ex.getMessage());
		}
	}

	private void fileContentChanged()
	{
		ideContext.getProxy().fileChanged(file);
	}

	public int getCaretPosition()
	{
		return syntaxTextArea.getCaretPosition();
	}

	public void setCaretPosition(int position)
	{
		syntaxTextArea.setCaretPosition(position);
	}

	private XmlFile getXmlFile()
	{
		if(!file.getName().toLowerCase().endsWith(".xml"))
		{
			return null;
		}

		try
		{
			XmlFile xmlFile = XmlFile.parse(syntaxTextArea.getText());
			return xmlFile;
		} catch(Exception ex)
		{
			logger.trace("Failed to parse xml file: " + file.getName() + " Error: " + ex);
			return null;
		}
	}

	public String getCurrentElementName(String nodeName)
	{
		XmlFile xmlFile = getXmlFile();

		if(xmlFile == null)
		{
			return null;
		}

		int curLineNo = syntaxTextArea.getCaretLineNumber();
		Element testSuiteElement = xmlFile.getElement(nodeName, curLineNo);

		if(testSuiteElement == null)
		{
			return null;
		}

		Attribute attr = testSuiteElement.getAttribute("name");

		if(attr == null || StringUtils.isBlank(attr.getValue()))
		{
			return null;
		}

		return attr.getValue();
	}

	public File getFile()
	{
		return file;
	}

	private CompletionProvider getStepsProvider()
	{
		DefaultCompletionProvider stepProvider = new DefaultCompletionProvider();
		String[] basepackage = { "com.yukthitech" };
		DocInformation docInformation = null;

		try
		{
			docInformation = DocGenerator.buildDocInformation(basepackage);
		} catch(Exception e)
		{
			throw new IllegalStateException("An error occured while loading document Information", e);
		}
		
		for(StepInfo step : docInformation.getSteps())
		{
			stepProvider.addCompletion((new BasicCompletion(stepProvider, step.getName(), "short discription", step.getDescription())));
		}
		return stepProvider;

	}

	@Override
	public void addNotify() {
		// TODO Auto-generated method stub
		super.addNotify();
		new Thread()
		{
			public void run()
			{
				parser = createParser();
				if(parser!=null){
					syntaxTextArea.addParser(parser);
				}
				
				spellParser = createSpellingParser();
				if(spellParser != null)
				{
					try
					{
						File useDict = File.createTempFile("spellDemo", ".txt");
						spellParser.setUserDictionary(useDict);
						syntaxTextArea.addParser(spellParser);

					} catch(Exception ex)
					{
						ex.printStackTrace();
					}
				}
			}
		}.start();
	}

	protected Parser createParser() {
		// TODO Auto-generated method stub
		String fname=file.getName().toLowerCase();
		if(fname.endsWith(".txt")){
			return createSpellingParser();
		}
		else if(fname.endsWith(".xml")){
			System.out.println("xml parser return from create parser");
			return new XmlParser();
		}
		return null;
	}
	
	protected SpellingParser createSpellingParser() {
		// TODO Auto-generated method stub
		SpellingParser spellParser;
		File zip = new File("src/main/resources/english_dic.zip");
		try
		{
			spellParser = SpellingParser.createEnglishSpellingParser(zip, true);
			File useDict = File.createTempFile("spellDemo", ".txt");
			spellParser.setUserDictionary(useDict);
			return spellParser;
		} catch(IOException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return null;
		
	}

	
	
}