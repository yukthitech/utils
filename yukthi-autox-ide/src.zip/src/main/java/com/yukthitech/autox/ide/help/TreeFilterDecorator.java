package com.yukthitech.autox.ide.help;

import java.util.function.BiPredicate;

import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

public class TreeFilterDecorator
{

	private final JTree tree;
	private DefaultMutableTreeNode originalRootNode;
	private BiPredicate<Object, String> userObjectMatcher;
	private JTextField filterField;
	DefaultTreeModel model;

	public TreeFilterDecorator(JTree tree, BiPredicate<Object, String> userObjectMatcher, JTextField filterField)
	{
		this.tree = tree;

		this.originalRootNode = (DefaultMutableTreeNode) tree.getModel().getRoot();
		this.userObjectMatcher = userObjectMatcher;
		this.filterField = filterField;
	}

	public static TreeFilterDecorator decorate(JTree tree, BiPredicate<Object, String> userObjectMatcher, JTextField filterField)
	{
		TreeFilterDecorator tfd = new TreeFilterDecorator(tree, userObjectMatcher, filterField);
		return tfd;
	}

	public JTextField getFilterField()
	{
		return filterField;
	}

	public void filterTree(String text)
	{
		model = (DefaultTreeModel) tree.getModel();
		text = filterField.getText().trim().toLowerCase();
		if(text.equals("") && tree.getModel().getRoot() != originalRootNode)
		{
			model.setRoot(originalRootNode);
			JTreeUtil.setTreeExpandedState(tree, true);
		}
		else
		{
			filterAndBuild(text, originalRootNode);
			// DefaultMutableTreeNode newRootNode = matchAndBuildNode(text,
			// originalRootNode);
			// model.setRoot(newRootNode);

			JTreeUtil.setTreeExpandedState(tree, true);
		}
	}

	
	private void filterAndBuild(String text, DefaultMutableTreeNode oldNode)
	{
		if(oldNode instanceof PluginInfoTreeNode){
			PluginInfoTreeNode plugin = (PluginInfoTreeNode) oldNode;
			if(plugin.getName().contains(text)){
				System.out.println(plugin.getName());
			}
		}
		else if(oldNode.isLeaf() && oldNode instanceof StepInfoTreeNode)
		{
			StepInfoTreeNode step = (StepInfoTreeNode) oldNode;
			if(step.getName().contains(text))
			{
				System.out.println(step.getName());
			}
		}
		if(oldNode.isRoot())
		{
			for(int i = 0; i < oldNode.getChildCount(); i++)
			{
				filterAndBuild(text, (DefaultMutableTreeNode) oldNode.getChildAt(i));
			}
		}

	}

	private DefaultMutableTreeNode matchAndBuildNode(final String text, DefaultMutableTreeNode oldNode)
	{
		DefaultMutableTreeNode newMatchedNode = null;
		// if(!oldNode.isRoot() &&
		// userObjectMatcher.test(oldNode.getUserObject(), text))
		// {
		// return JTreeUtil.copyNode(oldNode);
		// }
		// if(oldNode instanceof PluginInfoTreeNode){
		//// newMatchedNode = oldNode.isRoot() ? new
		// DefaultMutableTreeNode(oldNode.getUserObject()) : null;
		// newMatchedNode = oldNode.isRoot() ? oldNode:null;
		// PluginInfoTreeNode plugin = (PluginInfoTreeNode) oldNode;
		// for(DefaultMutableTreeNode childOldNode :
		// JTreeUtil.children(oldNode))
		// {
		// DefaultMutableTreeNode newMatchedChildNode = matchAndBuildNode(text,
		// childOldNode);
		// if(newMatchedChildNode != null)
		// {
		// if(newMatchedNode == null)
		// {
		//// newMatchedNode = new
		// DefaultMutableTreeNode(oldNode.getUserObject());
		// newMatchedNode = plugin;
		// }
		// newMatchedNode.add(plugin);
		// }
		// }
		// }
		//
		// else if(oldNode instanceof StepInforTreeNode)
		// {
		//// newMatchedNode = oldNode.isRoot() ? new
		// DefaultMutableTreeNode(oldNode.getUserObject()) : null;
		// newMatchedNode = oldNode.isRoot() ? oldNode:null;
		// StepInforTreeNode step = (StepInforTreeNode) oldNode;
		// for(DefaultMutableTreeNode childOldNode :
		// JTreeUtil.children(oldNode))
		// {
		// DefaultMutableTreeNode newMatchedChildNode = matchAndBuildNode(text,
		// childOldNode);
		// if(newMatchedChildNode != null)
		// {
		// if(newMatchedNode == null)
		// {
		//// newMatchedNode = new
		// DefaultMutableTreeNode(oldNode.getUserObject());
		// newMatchedNode = step;
		// }
		// newMatchedNode.add(step);
		// }
		// }
		//
		//
		//
		// }
		// else{
		if(!oldNode.isRoot() && userObjectMatcher.test(oldNode.getUserObject(), text))
		{
			return JTreeUtil.copyNode(oldNode);
		}
		if(oldNode instanceof PluginInfoTreeNode)
		{
			newMatchedNode = oldNode.isRoot() ? oldNode : null;
			System.out.println(oldNode.getUserObject());
		}
		if(oldNode instanceof StepInfoTreeNode)
		{
			newMatchedNode = oldNode.isRoot() ? oldNode : null;
			System.out.println(oldNode.getUserObject());
		}
		// newMatchedNode = oldNode.isRoot() ? new
		// DefaultMutableTreeNode(oldNode.getUserObject()) : null;
		for(DefaultMutableTreeNode childOldNode : JTreeUtil.children(oldNode))
		{
			DefaultMutableTreeNode newMatchedChildNode = matchAndBuildNode(text, childOldNode);
			if(newMatchedChildNode != null)
			{
				if(newMatchedNode == null)
				{
					newMatchedNode = new DefaultMutableTreeNode(oldNode.getUserObject());
				}
				newMatchedNode.add(newMatchedChildNode);

			}
		}
		// }

		return newMatchedNode;
	}

}
