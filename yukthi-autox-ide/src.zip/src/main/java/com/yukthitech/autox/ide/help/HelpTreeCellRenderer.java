package com.yukthitech.autox.ide.help;

import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

import org.apache.commons.lang3.StringUtils;

public class HelpTreeCellRenderer extends DefaultTreeCellRenderer
{
	private static final long serialVersionUID = 1L;

	private String searchText;
	
	public void setSearchText(String searchText)
	{
		this.searchText = searchText;
	}
	
	@Override
	public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus)
	{
		super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
		JLabel label = (JLabel) super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);

		String text = null;
		if(!StringUtils.isEmpty(searchText))
			text = searchText;
		{
			
			if(value instanceof PluginInfoTreeNode && !StringUtils.isEmpty(searchText)){
				PluginInfoTreeNode node = (PluginInfoTreeNode) value;
				text = (String) node.getName();
//				text = label.getText();
				text = "<html><body>" + text.replace(text, "<b>" +  text + "</b>") + "</body></html>";
				label.setText(text);
			}
			else if(value instanceof StepInfoTreeNode && !StringUtils.isEmpty(searchText)){
				StepInfoTreeNode node = (StepInfoTreeNode) value;
				text = (String) node.getName();
//				text = label.getText();
				text = "<html><body>" + text.replace(text, "<B>" +  text + "</B>") + "</body></html>";
				label.setText(text);
			}
//			else{
//				text = label.getText();
//				text = "<html><body>" + text.replace(text, "<B>" +  text + "</B>") + "</body></html>";
//				label.setText(text);
//			}
		}
		
//		text = "<html><body>" + text.replace(text, "<B>" +  text + "</B>") + "</body></html>";
		
		return label;
	}
}
