package com.yukthitech.autox.ide;

import org.fife.ui.autocomplete.BasicCompletion;
import org.fife.ui.autocomplete.DefaultCompletionProvider;
import org.fife.ui.autocomplete.ShorthandCompletion;

public class TestCaseCompletionProvider extends DefaultCompletionProvider
{
	public TestCaseCompletionProvider()
	{
		  super.addCompletion(new BasicCompletion(this, "abstract"));
	      super.addCompletion(new BasicCompletion(this, "assert"));
	      super.addCompletion(new BasicCompletion(this, "break"));
	      super.addCompletion(new BasicCompletion(this, "case"));
	      // ... etc ...
	      super.addCompletion(new BasicCompletion(this, "transient"));
	      super.addCompletion(new BasicCompletion(this, "try"));
	      super.addCompletion(new BasicCompletion(this, "void"));
	      super.addCompletion(new BasicCompletion(this, "volatile"));
	      super.addCompletion(new BasicCompletion(this, "while"));

	      // Add a couple of "shorthand" completions. These completions don't
	      // require the input text to be the same thing as the replacement text.
	      super.addCompletion(new ShorthandCompletion(this, "sysout",
	            "System.out.println(", "System.out.println("));
	      super.addCompletion(new ShorthandCompletion(this, "syserr",
	            "System.err.println(", "System.err.println("));

	}
}
