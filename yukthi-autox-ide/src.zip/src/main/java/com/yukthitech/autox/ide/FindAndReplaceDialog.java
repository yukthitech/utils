package com.yukthitech.autox.ide;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JRootPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import org.apache.commons.lang3.StringUtils;
import org.fife.ui.rtextarea.SearchContext;
import org.fife.ui.rtextarea.SearchEngine;

import com.yukthitech.autox.ide.editor.FileEditor;

public class FindAndReplaceDialog extends JDialog
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panel_1;
	private JPanel panel;
	private JButton btnNewButton;
	private JLabel label;
	private JTextField findTextField;
	private JLabel lblReplaceWith;
	private JTextField replaceText;
	private JPanel panel_2;
	private JPanel panel_3;
	private JRadioButton forward;
	private JRadioButton backword;
	private JCheckBox chckbxNewCheckBox;
	private JCheckBox chckbxNewCheckBox_1;
	private JButton btnNewButton_1;
	private JLabel result;
	private JButton btnReplaceAll;
	private ButtonGroup buttonGroup = new ButtonGroup();
	SearchContext context = new SearchContext();

	private FileEditor editor;

	public FindAndReplaceDialog()
	{
		setTitle("Find / Replace ");
		setResizable(false);
		getContentPane().add(getPanel(), BorderLayout.CENTER);
		getContentPane().add(getPanel_1(), BorderLayout.SOUTH);
		buttonGroup.add(forward);
		buttonGroup.add(backword);
		setSize(new Dimension(280, 250));
	}

	private JPanel getPanel_1()
	{
		if(panel_1 == null)
		{
			panel_1 = new JPanel();
			GridBagLayout gbl_panel_1 = new GridBagLayout();
			gbl_panel_1.columnWidths = new int[] { 87, 53, 77, 57, 0 };
			gbl_panel_1.rowHeights = new int[] { 0, 23, 0, 0 };
			gbl_panel_1.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
			gbl_panel_1.rowWeights = new double[] { 0.0, 0.0, 0.0, Double.MIN_VALUE };
			panel_1.setLayout(gbl_panel_1);
			GridBagConstraints gbc_result = new GridBagConstraints();
			gbc_result.insets = new Insets(0, 0, 5, 5);
			gbc_result.gridx = 0;
			gbc_result.gridy = 0;
			panel_1.add(getResult(), gbc_result);
			GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
			gbc_btnNewButton.fill = GridBagConstraints.HORIZONTAL;
			gbc_btnNewButton.anchor = GridBagConstraints.NORTH;
			gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
			gbc_btnNewButton.gridx = 1;
			gbc_btnNewButton.gridy = 1;
			panel_1.add(getBtnNewButton(), gbc_btnNewButton);
			GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
			gbc_btnNewButton_1.fill = GridBagConstraints.HORIZONTAL;
			gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 5);
			gbc_btnNewButton_1.anchor = GridBagConstraints.NORTH;
			gbc_btnNewButton_1.gridx = 2;
			gbc_btnNewButton_1.gridy = 1;
			panel_1.add(getBtnNewButton_1(), gbc_btnNewButton_1);
			GridBagConstraints gbc_btnReplaceAll = new GridBagConstraints();
			gbc_btnReplaceAll.fill = GridBagConstraints.HORIZONTAL;
			gbc_btnReplaceAll.insets = new Insets(0, 0, 0, 5);
			gbc_btnReplaceAll.gridx = 2;
			gbc_btnReplaceAll.gridy = 2;
			panel_1.add(getBtnReplaceAll(), gbc_btnReplaceAll);
		}
		return panel_1;
	}

	private JPanel getPanel()
	{
		if(panel == null)
		{
			panel = new JPanel();
			panel.setBorder(new EmptyBorder(10, 10, 10, 10));
			GridBagLayout gbl_panel = new GridBagLayout();
			gbl_panel.columnWidths = new int[] { 46, 0, 0 };
			gbl_panel.rowHeights = new int[] { 0, 0, 0, 0 };
			gbl_panel.columnWeights = new double[] { 1.0, 1.0, Double.MIN_VALUE };
			gbl_panel.rowWeights = new double[] { 0.0, 0.0, 1.0, Double.MIN_VALUE };
			panel.setLayout(gbl_panel);
			GridBagConstraints gbc_label = new GridBagConstraints();
			gbc_label.anchor = GridBagConstraints.WEST;
			gbc_label.insets = new Insets(0, 0, 5, 5);
			gbc_label.gridx = 0;
			gbc_label.gridy = 0;
			panel.add(getLabel(), gbc_label);
			GridBagConstraints gbc_findTextField = new GridBagConstraints();
			gbc_findTextField.insets = new Insets(0, 0, 5, 0);
			gbc_findTextField.fill = GridBagConstraints.HORIZONTAL;
			gbc_findTextField.gridx = 1;
			gbc_findTextField.gridy = 0;
			panel.add(getFindTextField(), gbc_findTextField);
			GridBagConstraints gbc_lblReplaceWith = new GridBagConstraints();
			gbc_lblReplaceWith.anchor = GridBagConstraints.WEST;
			gbc_lblReplaceWith.insets = new Insets(0, 0, 5, 5);
			gbc_lblReplaceWith.gridx = 0;
			gbc_lblReplaceWith.gridy = 1;
			panel.add(getLblReplaceWith(), gbc_lblReplaceWith);
			GridBagConstraints gbc_replaceText = new GridBagConstraints();
			gbc_replaceText.insets = new Insets(0, 0, 5, 0);
			gbc_replaceText.fill = GridBagConstraints.HORIZONTAL;
			gbc_replaceText.gridx = 1;
			gbc_replaceText.gridy = 1;
			panel.add(getReplaceText(), gbc_replaceText);
			GridBagConstraints gbc_panel_2 = new GridBagConstraints();
			gbc_panel_2.insets = new Insets(0, 0, 0, 5);
			gbc_panel_2.fill = GridBagConstraints.BOTH;
			gbc_panel_2.gridx = 0;
			gbc_panel_2.gridy = 2;
			panel.add(getPanel_2(), gbc_panel_2);
			GridBagConstraints gbc_panel_3 = new GridBagConstraints();
			gbc_panel_3.fill = GridBagConstraints.BOTH;
			gbc_panel_3.gridx = 1;
			gbc_panel_3.gridy = 2;
			panel.add(getPanel_3(), gbc_panel_3);
		}
		return panel;
	}

	private JButton getBtnNewButton()
	{
		if(btnNewButton == null)
		{
			btnNewButton = new JButton("Find Next");
			btnNewButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					result.setText("");
					context.setSearchFor(findTextField.getText());
					boolean found = SearchEngine.find(editor.getTextArea(), context).wasFound();
					if(!found)
					{
						result.setText("String Not Found");
					}
					System.out.println(buttonGroup.getSelection().getSelectedObjects());
				}
			});
		}
		return btnNewButton;
	}

	private JLabel getLabel()
	{
		if(label == null)
		{
			label = new JLabel("Find");
		}
		return label;
	}

	private JTextField getFindTextField()
	{
		if(findTextField == null)
		{
			findTextField = new JTextField();
			findTextField.setColumns(10);
		}
		return findTextField;
	}

	private JLabel getLblReplaceWith()
	{
		if(lblReplaceWith == null)
		{
			lblReplaceWith = new JLabel("Replace With");
		}
		return lblReplaceWith;
	}

	private JTextField getReplaceText()
	{
		if(replaceText == null)
		{
			replaceText = new JTextField();
			replaceText.setColumns(10);
		}
		return replaceText;
	}

	private JPanel getPanel_2()
	{
		if(panel_2 == null)
		{
			panel_2 = new JPanel();
			panel_2.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Direction", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			GridBagLayout gbl_panel_2 = new GridBagLayout();
			gbl_panel_2.columnWidths = new int[] { 0, 0 };
			gbl_panel_2.rowHeights = new int[] { 0, 0, 0 };
			gbl_panel_2.columnWeights = new double[] { 0.0, Double.MIN_VALUE };
			gbl_panel_2.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
			panel_2.setLayout(gbl_panel_2);
			GridBagConstraints gbc_forward = new GridBagConstraints();
			gbc_forward.anchor = GridBagConstraints.WEST;
			gbc_forward.insets = new Insets(0, 0, 5, 0);
			gbc_forward.gridx = 0;
			gbc_forward.gridy = 0;
			panel_2.add(getForward(), gbc_forward);
			GridBagConstraints gbc_backword = new GridBagConstraints();
			gbc_backword.anchor = GridBagConstraints.WEST;
			gbc_backword.gridx = 0;
			gbc_backword.gridy = 1;
			panel_2.add(getBackword(), gbc_backword);

		}
		return panel_2;
	}

	private JPanel getPanel_3()
	{
		if(panel_3 == null)
		{
			panel_3 = new JPanel();
			panel_3.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Options", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			GridBagLayout gbl_panel_3 = new GridBagLayout();
			gbl_panel_3.columnWidths = new int[] { 0, 0 };
			gbl_panel_3.rowHeights = new int[] { 0, 0, 0 };
			gbl_panel_3.columnWeights = new double[] { 0.0, Double.MIN_VALUE };
			gbl_panel_3.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
			panel_3.setLayout(gbl_panel_3);
			GridBagConstraints gbc_chckbxNewCheckBox = new GridBagConstraints();
			gbc_chckbxNewCheckBox.anchor = GridBagConstraints.WEST;
			gbc_chckbxNewCheckBox.insets = new Insets(0, 0, 5, 0);
			gbc_chckbxNewCheckBox.gridx = 0;
			gbc_chckbxNewCheckBox.gridy = 0;
			panel_3.add(getChckbxNewCheckBox(), gbc_chckbxNewCheckBox);
			GridBagConstraints gbc_chckbxNewCheckBox_1 = new GridBagConstraints();
			gbc_chckbxNewCheckBox_1.anchor = GridBagConstraints.WEST;
			gbc_chckbxNewCheckBox_1.gridx = 0;
			gbc_chckbxNewCheckBox_1.gridy = 1;
			panel_3.add(getChckbxNewCheckBox_1(), gbc_chckbxNewCheckBox_1);
		}
		return panel_3;
	}

	private JRadioButton getForward()
	{
		if(forward == null)
		{
			forward = new JRadioButton("forward");
			forward.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					context.setSearchForward(true);
				}
			});
			forward.setSelected(true);
		}
		return forward;
	}

	private JRadioButton getBackword()
	{
		if(backword == null)
		{
			backword = new JRadioButton("backword");
			backword.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					context.setSearchForward(false);
				}
			});
		}
		return backword;
	}

	private JCheckBox getChckbxNewCheckBox()
	{
		if(chckbxNewCheckBox == null)
		{
			chckbxNewCheckBox = new JCheckBox("Case Sensitive");
			chckbxNewCheckBox.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					if(chckbxNewCheckBox.isSelected())
					{
						context.setMatchCase(true);
					}
					else
					{
						context.setMatchCase(false);
					}
				}
			});
		}
		return chckbxNewCheckBox;
	}

	private JCheckBox getChckbxNewCheckBox_1()
	{
		if(chckbxNewCheckBox_1 == null)
		{
			chckbxNewCheckBox_1 = new JCheckBox("Regular Expression");
			chckbxNewCheckBox_1.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					if(chckbxNewCheckBox_1.isSelected())
					{
						context.setRegularExpression(true);
					}
					else
					{
						context.setRegularExpression(false);
					}
				}
			});
		}
		return chckbxNewCheckBox_1;
	}

	private JButton getBtnNewButton_1()
	{
		if(btnNewButton_1 == null)
		{
			btnNewButton_1 = new JButton("Replace");
			btnNewButton_1.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					result.setText("");
					context.setSearchFor(findTextField.getText());
					boolean found = SearchEngine.find(editor.getTextArea(), context).wasFound();
					if(!found)
					{
						result.setText("String not found");
					}
					if(!StringUtils.isEmpty(replaceText.getText()))
					{
						context.setReplaceWith(replaceText.getText());
						SearchEngine.replace(editor.getTextArea(), context);
					}

				}
			});
		}
		return btnNewButton_1;
	}

	private JLabel getResult()
	{
		if(result == null)
		{
			result = new JLabel("");
		}
		return result;
	}

	private JButton getBtnReplaceAll()
	{
		if(btnReplaceAll == null)
		{
			btnReplaceAll = new JButton("Replace All");
			btnReplaceAll.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					result.setText("");
					context.setSearchFor(findTextField.getText());
					boolean found = SearchEngine.find(editor.getTextArea(), context).wasFound();
					if(!found)
					{
						result.setText("String not found");
					}
					if(!StringUtils.isEmpty(replaceText.getText()))
					{
						context.setReplaceWith(replaceText.getText());
						SearchEngine.replaceAll(editor.getTextArea(), context);
					}
				}
			});
		}
		return btnReplaceAll;
	}

	
	@Override
	protected JRootPane createRootPane()
	{
		JRootPane rootPane = new JRootPane();
	    KeyStroke stroke = KeyStroke.getKeyStroke("ESCAPE");
	    Action actionListener = new AbstractAction() { 
	      /**
			 * 
			 */
			private static final long serialVersionUID = 1L;

		public void actionPerformed(ActionEvent actionEvent) { 
	        setVisible(false);
	      } 
	    } ;
	    InputMap inputMap = rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
	    inputMap.put(stroke, "ESCAPE");
	    rootPane.getActionMap().put("ESCAPE", actionListener);

	    return rootPane;
	}

	public void display(FileEditor editor)
	{
		this.editor = editor;
		super.setPreferredSize(getPreferredSize());
		super.setVisible(true);
	}
}
