package com.yukthitech.autox.ide.help;

import javax.swing.tree.DefaultMutableTreeNode;

import com.yukthitech.autox.doc.DocInformation;
import com.yukthitech.autox.doc.StepInfo;

public class StepInfoTreeNode extends DefaultMutableTreeNode //FilterableTreeNode
{
	private static final long serialVersionUID = 1L;
	private String name;
	private StepInfo stepInfo;

	public StepInfoTreeNode(StepInfo step, DocInformation docInformation)
	{
		super(step.getName());
		this.name=step.getName();
		this.stepInfo = step;
	}

	public StepInfo getStepInfo()
	{
		return stepInfo;
	}

	public String getName()
	{
		return name;
	}
	

}
