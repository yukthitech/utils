package com.yukthitech.autox.ide.editor;

import org.fife.ui.rsyntaxtextarea.RSyntaxDocument;
import org.fife.ui.rsyntaxtextarea.parser.AbstractParser;
import org.fife.ui.rsyntaxtextarea.parser.ParseResult;

public class MyParser extends AbstractParser
{
	public MyParser()
	{
		super();
	}
	@Override
	public ParseResult parse(RSyntaxDocument arg0, String arg1)
	{
		// TODO Auto-generated method stub
		return null;
	}

}
