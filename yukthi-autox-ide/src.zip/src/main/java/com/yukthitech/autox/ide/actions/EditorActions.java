package com.yukthitech.autox.ide.actions;

import org.springframework.beans.factory.annotation.Autowired;

import com.yukthitech.autox.ide.FindAndReplaceDialog;
import com.yukthitech.autox.ide.editor.FileEditor;
import com.yukthitech.autox.ide.editor.FileEditorTabbedPane;
import com.yukthitech.autox.ide.layout.Action;
import com.yukthitech.autox.ide.layout.ActionHolder;

@ActionHolder
public class EditorActions
{
	@Autowired
	private FileEditorTabbedPane fileEditorTabbedPane;

	private FindAndReplaceDialog findAndReplaceDialog;

	@Action
	public void FindAndReplace()
	{
		if(findAndReplaceDialog == null)
		{
			findAndReplaceDialog = new FindAndReplaceDialog();
		}
		FileEditor fileEditor = (FileEditor) fileEditorTabbedPane.getSelectedComponent();
		findAndReplaceDialog.display(fileEditor);
	}

}
