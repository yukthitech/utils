package com.yukthitech.autox.ide.postman;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class PostmanRequest extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JComboBox<String> comboBox;
	private JTextField textField;
	private JButton button;
	private JTabbedPane tabbedPane;
	private PostmanHeaders postmanHeaders;
	private PostmanBody postmanBody;

	/**
	 * Create the panel.
	 */
	public PostmanRequest() {
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{65, 70, 59, 0};
		gridBagLayout.rowHeights = new int[]{23, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		setLayout(gridBagLayout);
		GridBagConstraints gbc_comboBox = new GridBagConstraints();
		gbc_comboBox.anchor = GridBagConstraints.WEST;
		gbc_comboBox.insets = new Insets(0, 0, 5, 5);
		gbc_comboBox.gridx = 0;
		gbc_comboBox.gridy = 0;
		add(getComboBox(), gbc_comboBox);
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.gridx = 1;
		gbc_textField.gridy = 0;
		add(getTextField(), gbc_textField);
		GridBagConstraints gbc_button = new GridBagConstraints();
		gbc_button.insets = new Insets(0, 0, 5, 0);
		gbc_button.anchor = GridBagConstraints.NORTHWEST;
		gbc_button.gridx = 2;
		gbc_button.gridy = 0;
		add(getButton(), gbc_button);
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.gridwidth = 3;
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 1;
		add(getTabbedPane(), gbc_tabbedPane);
		this.setMinimumSize(new Dimension(10, 300));

	}
	private JComboBox<String> getComboBox() {
		if (comboBox == null) {
			comboBox = new JComboBox<>();
			comboBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(comboBox.getSelectedItem().toString().equals("GET"))
					{
						tabbedPane.setSelectedIndex(0);
						tabbedPane.setEnabledAt(1, false);
					}
					else{
						tabbedPane.setEnabledAt(1, true);
					}
				}
			});
			comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"GET", "POST", "PUT", "DELETE"}));
		}
		return comboBox;
	}
	private JTextField getTextField() {
		if (textField == null) {
			textField = new JTextField();
			textField.setColumns(10);
		}
		return textField;
	}
	private JButton getButton() {
		if (button == null) {
			button = new JButton("Send");
		}
		return button;
	}
	private JTabbedPane getTabbedPane() {
		if (tabbedPane == null) {
			tabbedPane = new JTabbedPane(JTabbedPane.TOP);
			tabbedPane.addTab("Header", null, getPostmanHeaders(), null);
			tabbedPane.addTab("Body", null, getPostmanBody(), null);
		}
		return tabbedPane;
	}
	private PostmanHeaders getPostmanHeaders() {
		if (postmanHeaders == null) {
			postmanHeaders = new PostmanHeaders();
		}
		return postmanHeaders;
	}
	private PostmanBody getPostmanBody() {
		if (postmanBody == null) {
			postmanBody = new PostmanBody();
		}
		return postmanBody;
	}
}
